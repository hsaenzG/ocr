import{n as e,t}from"./api.t6LoSMCi.js";var n=document.getElementById(`stat-uploaded`),r=document.getElementById(`stat-completed`),i=document.getElementById(`stat-failed`),a=document.getElementById(`stat-processing`),o=document.getElementById(`series-body`),s=document.getElementById(`dash-error`);(async()=>{try{let t=await e.statsSummary();if(n.textContent=String(t.totals.uploaded),r.textContent=String(t.totals.completed),i.textContent=String(t.totals.failed),a.textContent=String(t.totals.processing),t.series.length===0){o.innerHTML=`<tr><td colspan="4" class="muted">Sin stats todavía.</td></tr>`;return}o.innerHTML=[...t.series].reverse().map(e=>`<tr>
            <td>${e.date}</td>
            <td>${e.uploaded}</td>
            <td>${e.completed}</td>
            <td>${e.failed}</td>
          </tr>`).join(``)}catch(e){s.hidden=!1,s.textContent=e instanceof t||e instanceof Error?e.message:`Error cargando dashboard`}})();